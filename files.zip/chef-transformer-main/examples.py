EXAMPLES = {
    "Turkish Food": "phyllo dough, unsalted butter, walnuts, cinnamon, water, honey, melted chocolate",
    "Abudhabi Food": "beef, oil, onion, tomatoes, turmeric powder, limes, water, salt, pepper, red beans, herb",
    "North Korea Food ": "beef, potatoes, eggs, onion, flour, turmeric powder, oil, salt, pepper",
    "Brazil Food": "walnut pieces, onion, boneless skinless chicken thighs, pomegranate molasses, orange juice, chicken stock, cinnamon, salt, pepper, oil",
    "Mexico Food": "water, dry active yeast, flour, salt, olive oil, ground beef, onion, pepper, salt, feta cheese, parsley, lemon",
    "Turkey Food": "pork chops, soy sauce, honey, garlic, sesame oil, fresh ginger root, sweet chili sauce, olive oil",
    "Italian Food": "rotini pasta, broccoli florets, parmesan cheese, red pepper, onions, black olives",
    "German Food": "oil, boneless pork chops, salt, pepper, flour, eggs, breadcrumbs, gravy, parsley"
}
